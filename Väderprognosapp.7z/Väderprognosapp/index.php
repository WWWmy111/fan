<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VäderPrognosApp</title>
<style>

    body {
        background-image: url('https://i.pinimg.com/originals/4c/50/67/4c50672068dabc5ca0ac0c13c8b26066.gif');
        background-size: cover; /* Anpassa storleken efter fönstrets storlek */
        background-repeat: no-repeat; /* Förhindra upprepning av bilden */
        animation: slide 20s linear infinite; /* Använd en animering för att skapa rörelsen */
        background-color: black; /* Set the background color */
    }

    #main, #main1, #main2, #weather, #wind{
        text-align: center;
        margin-top: 50px;
        font-size: 18px;
        color: white;
    }

    .title{
      color: white;
    }

</style>
</head>

<body>
<center>
  <h1 class="title">Välkommen!</h1>
  <br><br><br>

  <form id="form" method="GET">
      <input type="text" id="registration" name="city" placeholder="Skriv staden här..."> <!-- Added ID "registration" -->
      <input type="submit" value="sök">
  </form>
</center>


<div id="main"></div>
<div id="main1"></div>
<div id="main2"></div>
<div id="weather"></div>
<div id="wind"></div>

<script>
const form = document.getElementById('form')

form.addEventListener('submit', validateForm, true)

function validateForm(e) {
    e.preventDefault()
    var registration = document.getElementById("registration").value;
    if (registration == "") {
        alert("Du har inte skivit in någon stad!");
        return false; // Förhindrar att formuläret skickas om fältet är tomt
    }

    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${registration}&appid=37ca420ab6cba0cb9de02568469dbbeb`).then(async (weather) => {
        const data = await weather.json()
        console.log(data);

        const celsius = (data.main.temp - 273.15).toFixed(2);
        const Feels_celsius = (data.main.feels_like - 273.15).toFixed(2);

        document.getElementById('main').innerHTML = celsius + " ℃";
        document.getElementById('main1').innerHTML = Feels_celsius + " ℃";
        document.getElementById('main2').innerHTML = data.main.humidity + "% humidity";
        document.getElementById('weather').innerHTML = data.weather[0].description;
        document.getElementById('wind').innerHTML = data.wind.speed + " m/s";

    })

    return true; // Skickar formuläret om fältet inte är tomt
}
</script>

</body>
</html>